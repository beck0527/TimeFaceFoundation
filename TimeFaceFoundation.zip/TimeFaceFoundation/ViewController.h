//
//  ViewController.h
//  TimeFaceFoundation
//
//  Created by 鲍振华 on 2018/4/29.
//  Copyright © 2018年 鲍振华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

