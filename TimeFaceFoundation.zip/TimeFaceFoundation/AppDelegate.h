//
//  AppDelegate.h
//  TimeFaceFoundation
//
//  Created by 鲍振华 on 2018/4/29.
//  Copyright © 2018年 鲍振华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

